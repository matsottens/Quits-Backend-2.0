"use client"

import LoadingScreen from "../loading-screen"

export default function SyntheticV0PageForDeployment() {
  return <LoadingScreen />
}