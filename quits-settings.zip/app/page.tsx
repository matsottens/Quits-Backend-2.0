"use client"

import SettingsPage from "../settings-page"

export default function SyntheticV0PageForDeployment() {
  return <SettingsPage />
}