"use client"

import { ArrowLeft, Bell, Calendar, DollarSign } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

interface SubscriptionDetailsProps {
  appName: string
  appLogo?: string
  currentPrice: string
  expiryDate: string
  notificationDate: string
  nextPrice: string
  onCancel?: () => void
  onContactSupport?: () => void
}

export default function SubscriptionDetails({
  appName,
  appLogo,
  currentPrice,
  expiryDate,
  notificationDate,
  nextPrice,
  onCancel,
  onContactSupport,
}: SubscriptionDetailsProps) {
  // Function to get logo URL based on app name
  const getLogoUrl = (name: string): string => {
    const appLogos: Record<string, string> = {
      Volkskrant: "https://www.volkskrant.nl/static/img/vk-logo.svg",
      Netflix: "https://assets.nflxext.com/us/ffe/siteui/common/icons/nfLogo.ico",
      Spotify:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Spotify_Primary_Logo_RGB_Green-nWpyxkMllvwSm0hV2S5Q5dscG50GRB.png",
      "Disney+": "https://static-assets.bamgrid.com/product/disneyplus/favicons/favicon.ico",
      "HBO Max": "https://hbomax-images.warnermediacdn.com/2020-05/square%20social%20logo%20400%20x%20400_0.png",
      // Add more app logos as needed
    }

    return appLogos[name] || "/placeholder.svg"
  }

  return (
    <div className="flex flex-col min-h-screen font-sans antialiased">
      {/* Header */}
      <header className="bg-[#1e3a70] text-white p-6 shadow-md">
        <div className="flex items-center mb-8">
          <Link href="/dashboard" className="mr-4 hover:opacity-80 transition-opacity">
            <ArrowLeft size={24} strokeWidth={2.5} />
            <span className="sr-only">Back to Dashboard</span>
          </Link>
          <h1 className="text-2xl font-semibold tracking-tight">Subscription Details</h1>
        </div>

        <div className="flex items-center">
          <div className="bg-white rounded-full w-16 h-16 flex items-center justify-center mr-5 shadow-sm overflow-hidden">
            <Image
              src={appLogo || getLogoUrl(appName)}
              alt={`${appName} logo`}
              width={48}
              height={48}
              className="object-contain"
            />
          </div>
          <div>
            <h2 className="text-2xl font-bold tracking-tight">{appName}</h2>
            <p className="text-base text-white/90 font-medium mt-0.5">Subscription Information</p>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="flex-grow bg-[#ffecd1] p-6">
        <h2 className="text-2xl font-bold tracking-tight text-gray-900 mb-8">Subscription Details</h2>

        <div className="space-y-0 divide-y divide-gray-300/70 rounded-lg overflow-hidden bg-white/50 shadow-sm">
          {/* Price */}
          <div className="flex items-center justify-between p-5">
            <div className="flex items-center">
              <div className="bg-gray-100 rounded-full w-12 h-12 flex items-center justify-center mr-4 shadow-sm">
                <DollarSign className="text-gray-700 size-5" />
              </div>
              <span className="text-base font-medium text-gray-800">Price</span>
            </div>
            <span className="text-lg font-semibold text-gray-900">{currentPrice}</span>
          </div>

          {/* Expiry Date */}
          <div className="flex items-center justify-between p-5">
            <div className="flex items-center">
              <div className="bg-gray-100 rounded-full w-12 h-12 flex items-center justify-center mr-4 shadow-sm">
                <Calendar className="text-gray-700 size-5" />
              </div>
              <span className="text-base font-medium text-gray-800">Expiry Date</span>
            </div>
            <span className="text-lg font-semibold text-gray-900">{expiryDate}</span>
          </div>

          {/* Notification Date */}
          <div className="flex items-center justify-between p-5">
            <div className="flex items-center">
              <div className="bg-gray-100 rounded-full w-12 h-12 flex items-center justify-center mr-4 shadow-sm">
                <Bell className="text-gray-700 size-5" />
              </div>
              <span className="text-base font-medium text-gray-800">Notification Date</span>
            </div>
            <span className="text-lg font-semibold text-gray-900">{notificationDate}</span>
          </div>

          {/* Next Price */}
          <div className="flex items-center justify-between p-5">
            <div className="flex items-center">
              <div className="bg-gray-100 rounded-full w-12 h-12 flex items-center justify-center mr-4 shadow-sm">
                <DollarSign className="text-gray-700 size-5" />
              </div>
              <span className="text-base font-medium text-gray-800">Next Price</span>
            </div>
            <span className="text-lg font-semibold text-gray-900">{nextPrice}</span>
          </div>
        </div>

        {/* Buttons */}
        <div className="mt-10 space-y-4">
          <Button
            variant="outline"
            className="w-full py-6 text-base font-medium border-gray-400 rounded-md hover:bg-gray-50 transition-colors"
            onClick={onCancel}
          >
            Cancel Subscription
          </Button>

          <Button
            variant="default"
            className="w-full py-6 text-base font-medium bg-gray-900 hover:bg-gray-800 text-white rounded-md transition-colors"
            onClick={onContactSupport}
          >
            Contact Support
          </Button>
        </div>
      </main>
    </div>
  )
}

