import SubscriptionDetails from "../app/components/subscription-details"

export default function SpotifyExample() {
  const handleCancel = () => {
    console.log("Cancellation requested")
    // Add your cancellation logic here
  }

  const handleContactSupport = () => {
    console.log("Contact support requested")
    // Add your support contact logic here
  }

  return (
    <SubscriptionDetails
      appName="Spotify"
      currentPrice="€9,99/month"
      expiryDate="3rd September 2025"
      notificationDate="3rd August 2025"
      nextPrice="€10,99/month"
      onCancel={handleCancel}
      onContactSupport={handleContactSupport}
    />
  )
}

